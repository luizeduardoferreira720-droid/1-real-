# 1 Real — primeira versão

Aplicativo simples de uma moeda de R$1.

## Funcionamento
- Abre com uma moeda realista.
- Toque na moeda.
- Ela gira e cai/assenta com uma pequena animação.
- Uma nova moeda aparece no lugar.
- A interface não usa logo de iPhone nem marca de fabricante.

## Como gerar o APK
1. Instale o Flutter SDK.
2. Na pasta do projeto rode:
   flutter pub get
3. Para testar:
   flutter run
4. Para gerar APK:
   flutter build apk --release

## Publicação
Para colocar na Google Play é necessário uma conta de desenvolvedor e o cadastro do aplicativo.
Para a App Store é necessário uma conta Apple Developer e um build iOS assinado.
O preço de R$1,00 e a disponibilidade precisam ser configurados nas respectivas lojas.

O efeito sonoro de moeda está incluído localmente no projeto, sem depender de internet.
