import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const OneRealApp());
}

class OneRealApp extends StatelessWidget {
  const OneRealApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '1 Real',
      theme: ThemeData.dark(useMaterial3: true),
      home: const CoinPage(),
    );
  }
}

class CoinPage extends StatefulWidget {
  const CoinPage({super.key});

  @override
  State<CoinPage> createState() => _CoinPageState();
}

class _CoinPageState extends State<CoinPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final AudioPlayer _audio = AudioPlayer();
  bool _busy = false;
  int _coinKey = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1050),
    )..forward();
  }

  Future<void> _dropCoin() async {
    if (_busy) return;
    setState(() => _busy = true);

    try {
      await _audio.stop();
      await _audio.play(AssetSource('coin.wav'), volume: 0.9);
    } catch (_) {}

    await _controller.forward(from: 0);

    if (!mounted) return;
    setState(() {
      _coinKey++;
      _busy = false;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final coinSize = math.min(size.width * .62, 310.0);

    return Scaffold(
      backgroundColor: const Color(0xFF090909),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(0, .15),
                    radius: 1.05,
                    colors: [Color(0xFF202020), Color(0xFF080808)],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 26,
              left: 22,
              right: 22,
              child: Row(
                children: [
                  ClipOval(
                    child: Image.asset(
                      'assets/coin.png',
                      width: 44,
                      height: 44,
                      fit: BoxFit.cover,
                      alignment: const Alignment(.5, .15),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '1 Real',
                        style: TextStyle(
                          fontSize: 23,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .2,
                        ),
                      ),
                      Text(
                        'R\$ 1,00',
                        style: TextStyle(
                          fontSize: 16,
                          color: Color(0xFFBDBDBD),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Center(
              child: GestureDetector(
                onTap: _dropCoin,
                behavior: HitTestBehavior.opaque,
                child: SizedBox(
                  width: coinSize + 80,
                  height: coinSize + 260,
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      final t = Curves.easeInOutCubic.transform(_controller.value);
                      // New coin starts high, falls to its resting point,
                      // flips and settles with a tiny natural bounce.
                      final fall = 130 * (1 - t);
                      final bounce = _controller.value > .82
                          ? math.sin((_controller.value - .82) / .18 * math.pi) * 8
                          : 0.0;
                      final angle = t * math.pi * 4.0;
                      final perspective = .72 + .28 * (math.cos(angle).abs());
                      final opacity = (_controller.value < .08)
                          ? _controller.value / .08
                          : 1.0;

                      return Opacity(
                        opacity: opacity,
                        child: Transform.translate(
                          offset: Offset(0, -fall + bounce),
                          child: Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.identity()
                              ..setEntry(3, 2, 0.0012)
                              ..rotateY(angle)
                              ..scale(perspective, 1.0),
                            child: Container(
                              key: ValueKey(_coinKey),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(.65),
                                    blurRadius: 24,
                                    spreadRadius: 2,
                                    offset: const Offset(0, 18),
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/coin.png',
                                  width: coinSize,
                                  height: coinSize,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 30,
              left: 0,
              right: 0,
              child: Center(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 250),
                  opacity: _busy ? 0.0 : 1.0,
                  child: const Text(
                    'TOQUE NA MOEDA',
                    style: TextStyle(
                      fontSize: 12,
                      letterSpacing: 2.2,
                      color: Color(0xFF9E9E9E),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
